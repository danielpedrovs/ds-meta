package com.devsuperior.sdsdsmeta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SdsDsMetaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SdsDsMetaApplication.class, args);
	}

}
