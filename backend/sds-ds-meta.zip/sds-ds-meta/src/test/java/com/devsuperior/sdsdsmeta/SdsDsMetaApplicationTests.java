package com.devsuperior.sdsdsmeta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SdsDsMetaApplicationTests {

	@Test
	void contextLoads() {
	}

}
